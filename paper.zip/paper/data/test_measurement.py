#!/usr/bin/env python3
"""Guard the one number the paper rests on.

Every figure in the paper is a function of `remaining_pct`, and `remaining_pct` is a
function of which token field the exporters read. There are two plausible fields and only
one correct one:

    last_token_usage.input_tokens    how full the context was for this request   <- correct
    total_token_usage.input_tokens   what the session has cost so far            <- wrong

The wrong field accumulates, so dividing it by the window climbs past 100% and the
"remaining" figure goes negative on any long run. A run that silently switched fields
would still produce plausible-looking curves for short sessions and nonsense for the deep
ones the paper is actually about -- which is the failure this file exists to catch.

Usage:  python3 test_measurement.py     (exits non-zero on failure)
"""

import json
import pathlib
import sys
import tempfile

from export_turn_curves import is_real_user_turn, session_turns

WINDOW = 200_000


def record(**info):
    return json.dumps({"payload": {"type": "token_count", "info": info}})


def usage(last_input, total_input):
    return {
        "last_token_usage": {"input_tokens": last_input},
        "total_token_usage": {"input_tokens": total_input},
        "model_context_window": WINDOW,
    }


def user_message(text, kind=None):
    payload = {"type": "user_message", "message": text}
    if kind is not None:
        payload["kind"] = kind
    return json.dumps({"payload": payload})


def write_rollout(lines):
    handle = tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False)
    handle.write("\n".join(lines) + "\n")
    handle.close()
    return pathlib.Path(handle.name)


FAILURES = []


def check(name, actual, expected):
    if actual == expected:
        print(f"  ok   {name}")
    else:
        print(f"  FAIL {name}: got {actual!r}, want {expected!r}")
        FAILURES.append(name)


# ---------- the field itself ----------
# A session whose per-request context is flat at 20,000 tokens while its running total
# climbs past the window. Reading the right field gives a flat 90%; reading the wrong one
# gives a curve that falls off the bottom of the axis.

path = write_rollout([
    user_message("first turn"),
    record(**usage(20_000, 20_000)),
    record(**usage(20_000, 40_000)),
    record(**usage(20_000, 220_000)),   # total has now exceeded the window
])
rows, pruned = session_turns(path)
check("reads last_token_usage, not total", [pct for _, _, _, pct in rows], [90.0, 90.0, 90.0])
check("no reading is negative", all(pct >= 0 for *_, pct in rows), True)
path.unlink()

# ---------- turn boundaries ----------
# Sessions open with injected context recorded exactly like typed input. Counting those
# as turns puts three or four "turns" before the session's first real request, which
# shifts every point in the turn-depth figure one bucket to the right.

check("injected context is not a turn", is_real_user_turn({"type": "user_message", "kind": "environment_context"}), False)
check("plain input is a turn", is_real_user_turn({"type": "user_message", "kind": "plain"}), True)
check("kindless input is a turn", is_real_user_turn({"type": "user_message", "message": "hi"}), True)

path = write_rollout([
    user_message("session preamble", kind="environment_context"),
    user_message("real first message"),
    record(**usage(10_000, 10_000)),
    user_message("real second message"),
    record(**usage(30_000, 40_000)),
])
rows, _ = session_turns(path)
check("turn numbering ignores preamble", [turn for turn, *_ in rows], [1, 2])
check("request counter resets each turn", [req for _, req, *_ in rows], [1, 1])
check("seq counts across the session", [seq for _, _, seq, _ in rows], [1, 2])
path.unlink()

# ---------- requests before the first user turn ----------
# Prewarm and startup requests happen before anything is typed. They belong to no turn and
# must not be attributed to turn 1.

path = write_rollout([
    record(**usage(1_000, 1_000)),
    user_message("first typed message"),
    record(**usage(10_000, 11_000)),
])
rows, _ = session_turns(path)
check("pre-turn requests are dropped", len(rows), 1)
path.unlink()

# ---------- the pruned/unpruned split ----------
# `pruned` is the only automatic signal separating the two conditions in the archive. If it
# stopped firing, every pruned session would silently be counted as a control.

path = write_rollout([
    user_message("turn"),
    record(**usage(10_000, 10_000)),
    json.dumps({"payload": {"type": "token_count", "context_prune_saved_tokens": 4_242,
                            "info": usage(6_000, 16_000)}}),
])
_, pruned = session_turns(path)
check("prune marker sets the condition flag", pruned, True)
path.unlink()

print()
if FAILURES:
    print(f"{len(FAILURES)} check(s) failed: {', '.join(FAILURES)}")
    sys.exit(1)
print("measurement is intact")
