"""Figures built from preserved session records rather than from a hand-run comparison.

Usage:  python3 make_figures_evidence.py
Writes: ../figures/fig_turn_depth_box.pdf    context held, by turn depth
        ../figures/fig_trajectory.pdf        context held, across a session's requests
        ../figures/fig_distribution.pdf       where readings land, both conditions

Input is turn_curves.csv from export_turn_curves.py, which reads every session rollout on
disk directly. Nothing here is hand-entered.
"""

import collections
import csv
import os
import statistics

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

for f in fm.findSystemFonts(fontpaths=["/usr/share/texmf/fonts/opentype/public/lm"]):
    fm.fontManager.addfont(f)
plt.rcParams["font.family"] = "Latin Modern Roman"
plt.rcParams["mathtext.fontset"] = "cm"
plt.rcParams["axes.unicode_minus"] = False

BLUE = "#2a78d6"
GRAY = "#898781"
GRAY_TEXT = "#52514e"
INK = "#0b0b0b"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
SURFACE = "#fcfcfb"

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, os.pardir, "figures")

# Pruning fires when the window is 30% used and reclaims back to 25%, so it holds the
# context between 70% and 75% remaining. Both are constants in context_pruner.rs.
TRIGGER_REMAINING = 70
TARGET_REMAINING = 75

# Below this many sessions a summary statistic is describing a handful of runs, not a
# tendency, so the curves stop rather than trail off into noise.
MIN_SESSIONS = 8


def style_axes(ax):
    ax.set_facecolor(SURFACE)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(AXIS)
    ax.spines["bottom"].set_color(AXIS)
    ax.tick_params(colors=GRAY_TEXT, labelsize=9)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)


def quartiles(values):
    values = sorted(values)
    mid = statistics.median(values)
    lower = values[: len(values) // 2]
    upper = values[(len(values) + 1) // 2:]
    return (statistics.median(lower) if lower else mid, mid,
            statistics.median(upper) if upper else mid)


ROWS = list(csv.DictReader(open(os.path.join(HERE, "turn_curves.csv"))))
PRUNED_SESSIONS = len({r["session"] for r in ROWS if r["pruned"] == "1"})
PLAIN_SESSIONS = len({r["session"] for r in ROWS if r["pruned"] == "0"})


# ---------- Figure C: context held by turn depth ----------
# Boxes, not means: the claim is about where the bulk of requests land, and a mean hides
# that unpruned sessions develop a long tail toward an exhausted window.

BUCKETS = [(1, 1, "1"), (2, 2, "2"), (3, 3, "3"), (4, 5, "4-5"), (6, 10, "6-10"), (11, 10**6, "11+")]

pruned = collections.defaultdict(list)
plain = collections.defaultdict(list)
for row in ROWS:
    turn, pct = int(row["turn"]), float(row["remaining_pct"])
    bucket = next(label for lo, hi, label in BUCKETS if lo <= turn <= hi)
    (pruned if row["pruned"] == "1" else plain)[bucket].append(pct)

labels = [label for _, _, label in BUCKETS]
positions = range(len(labels))

fig, ax = plt.subplots(figsize=(6.2, 3.5), dpi=300)
style_axes(ax)
ax.axhspan(TRIGGER_REMAINING, TARGET_REMAINING, color=BLUE, alpha=0.12, zorder=1, linewidth=0)
ax.axhline(TRIGGER_REMAINING, color=BLUE, linewidth=0.8, linestyle=(0, (4, 3)), zorder=2)


def draw_boxes(groups, offset, color, fill_alpha):
    ax.boxplot([groups[label] for label in labels],
               positions=[p + offset for p in positions], widths=0.34,
               patch_artist=True, showfliers=False,
               medianprops=dict(color=INK, linewidth=1.3),
               whiskerprops=dict(color=color, linewidth=0.9),
               capprops=dict(color=color, linewidth=0.9),
               boxprops=dict(facecolor=color, alpha=fill_alpha, edgecolor=color, linewidth=0.9),
               zorder=3)


draw_boxes(plain, -0.19, GRAY, 0.30)
draw_boxes(pruned, 0.19, BLUE, 0.34)

for i, label in enumerate(labels):
    ax.annotate(f"{statistics.median(pruned[label]):.0f}", (i + 0.19, 101), fontsize=7.4,
                color=BLUE, ha="center", va="bottom", annotation_clip=False)
    ax.annotate(f"{statistics.median(plain[label]):.0f}", (i - 0.19, 101), fontsize=7.4,
                color=GRAY_TEXT, ha="center", va="bottom", annotation_clip=False)

ax.set_xticks(list(positions))
ax.set_xticklabels(labels, fontsize=9, color=INK)
ax.set_xlabel("Turn depth within the session", fontsize=9.5, color=INK, labelpad=6)
ax.set_ylabel("Active context remaining (%)", fontsize=9.5, color=INK)
ax.set_ylim(0, 100)
ax.set_xlim(-0.55, len(labels) - 0.05)

handles = [
    plt.Rectangle((0, 0), 1, 1, facecolor=BLUE, alpha=0.34, edgecolor=BLUE, label="Pruning active"),
    plt.Rectangle((0, 0), 1, 1, facecolor=GRAY, alpha=0.30, edgecolor=GRAY, label="No pruning"),
    plt.Rectangle((0, 0), 1, 1, facecolor=BLUE, alpha=0.12, edgecolor="none",
                  label=f"Pruning band ({TRIGGER_REMAINING}-{TARGET_REMAINING}%)"),
]
leg = ax.legend(handles=handles, loc="lower left", frameon=False, fontsize=8.6, ncol=3,
                handlelength=1.3, borderaxespad=0.3, columnspacing=1.4)
for text in leg.get_texts():
    text.set_color(INK)

fig.tight_layout()
fig.savefig(os.path.join(OUT, "fig_turn_depth_box.pdf"))
plt.close(fig)


# ---------- Figure D: trajectory across a session ----------
# Turn depth hides the shape of the decay. Plotted against the running request count, the
# unpruned curve slopes down for as long as the session lasts while the pruned one flattens.

by_seq = {0: collections.defaultdict(list), 1: collections.defaultdict(list)}
sessions_at_seq = {0: collections.defaultdict(set), 1: collections.defaultdict(set)}
for row in ROWS:
    key = int(row["pruned"])
    seq = int(row["seq"])
    by_seq[key][seq].append(float(row["remaining_pct"]))
    sessions_at_seq[key][seq].add(row["session"])


def curve(key):
    xs, lo, mid, hi = [], [], [], []
    for seq in sorted(by_seq[key]):
        if len(sessions_at_seq[key][seq]) < MIN_SESSIONS:
            break
        q1, q2, q3 = quartiles(by_seq[key][seq])
        xs.append(seq)
        lo.append(q1)
        mid.append(q2)
        hi.append(q3)
    return xs, lo, mid, hi


fig, ax = plt.subplots(figsize=(6.2, 3.5), dpi=300)
style_axes(ax)
ax.axhspan(TRIGGER_REMAINING, TARGET_REMAINING, color=BLUE, alpha=0.12, zorder=1, linewidth=0)

# Both curves are cut at the same request, the last one where both conditions still have
# MIN_SESSIONS behind them. Letting the unpruned curve run on alone would put most of the
# axis under a single condition and make the comparison look longer than the evidence is.
horizon = min(curve(0)[0][-1], curve(1)[0][-1])

for key, color, width, label in ((0, GRAY, 1.5, "No pruning"), (1, BLUE, 2.1, "Pruning active")):
    xs, lo, mid, hi = curve(key)
    cut = sum(1 for x in xs if x <= horizon)
    xs, lo, mid, hi = xs[:cut], lo[:cut], mid[:cut], hi[:cut]
    ax.fill_between(xs, lo, hi, color=color, alpha=0.16, zorder=2, linewidth=0)
    ax.plot(xs, mid, color=color, linewidth=width, zorder=3, label=label)
    ax.annotate(f"{mid[-1]:.0f}%", (xs[-1], mid[-1]), xytext=(6, 0), textcoords="offset points",
                fontsize=8.5, color=color if key else GRAY_TEXT, va="center",
                fontweight="bold" if key else "normal")

ax.set_xlabel("Model requests into the session", fontsize=9.5, color=INK, labelpad=6)
ax.set_ylabel("Active context remaining (%)", fontsize=9.5, color=INK)
ax.set_ylim(0, 100)
ax.set_xlim(1, horizon * 1.07)

leg = ax.legend(loc="lower left", frameon=False, fontsize=8.8, handlelength=1.6, borderaxespad=0.3)
for text in leg.get_texts():
    text.set_color(INK)
ax.text(0.99, 0.97, "median, shaded interquartile range", transform=ax.transAxes,
        fontsize=7.6, color=GRAY_TEXT, ha="right", va="top")

fig.tight_layout()
fig.savefig(os.path.join(OUT, "fig_trajectory.pdf"))
plt.close(fig)


# ---------- Figure E: where readings land ----------
# The same readings as a distribution. Pruning does not merely shift the average; it
# concentrates requests into a narrow band and empties out the exhausted end of the window.

fig, ax = plt.subplots(figsize=(6.2, 2.9), dpi=300)
style_axes(ax)

bins = [b * 5 for b in range(21)]
for key, color, alpha, label in ((0, GRAY, 0.45, "No pruning"), (1, BLUE, 0.55, "Pruning active")):
    values = [float(r["remaining_pct"]) for r in ROWS if int(r["pruned"]) == key]
    ax.hist(values, bins=bins, weights=[100 / len(values)] * len(values),
            color=color, alpha=alpha, zorder=3, label=label)

ax.axvspan(TRIGGER_REMAINING, TARGET_REMAINING, color=BLUE, alpha=0.12, zorder=1, linewidth=0)
ax.set_xlabel("Active context remaining (%)", fontsize=9.5, color=INK, labelpad=6)
ax.set_ylabel("Share of requests (%)", fontsize=9.5, color=INK)
ax.set_xlim(0, 100)
ax.yaxis.grid(True, color=GRID, linewidth=0.8, zorder=0)

leg = ax.legend(loc="upper left", frameon=False, fontsize=8.8, handlelength=1.3, borderaxespad=0.4)
for text in leg.get_texts():
    text.set_color(INK)

fig.tight_layout()
fig.savefig(os.path.join(OUT, "fig_distribution.pdf"))
plt.close(fig)

print("wrote fig_turn_depth_box.pdf, fig_trajectory.pdf, fig_distribution.pdf")
print(f"  {len(ROWS):,} readings   pruned {PRUNED_SESSIONS} sessions   unpruned {PLAIN_SESSIONS}")
xs, _, mid, _ = curve(1)
xs0, _, mid0, _ = curve(0)
print(f"  trajectory runs to request {xs[-1]} (pruned, ends {mid[-1]:.1f}%)"
      f" and {xs0[-1]} (unpruned, ends {mid0[-1]:.1f}%)")
