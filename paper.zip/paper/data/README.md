# Figure source data

`context_retention.csv` holds every number plotted in both figures of the paper.
`make_figures.py` reads those numbers and produces
`figures/fig_context_retention.pdf` and `figures/fig_persona_breakdown.pdf`.

## How the numbers were produced

Same repository, clean workspace, same three prompts in order, run against Elpis
and against the matched Codex baseline. Three model routing tiers: Luna, Terra,
Sol — all GPT-5.6, all at high reasoning. Remaining active context was read off
each system's own context display at the end of every turn.

The main figure's per-turn mean is the average across the three tiers; its band
is the min–max across them. The per-tier figure reports each tier separately.

## Runs per condition

TODO — fill in the number of repeats behind each tier's min/max before
submission. This number belongs in the paper.

## Not measured

Whether the code produced in turns 2 and 3 was correct, Ace's own token cost and
latency, and end-to-end inspection of the audit trail for these runs. The paper
states these as open.
