#!/usr/bin/env python3
"""RQ5 - Auditability. Measures whether every pruning decision can be reconstructed.

Reads the pruning archive Elpis writes at ~/.elpis/logs/pruning/passes/. Each pass is one
Ace invocation; each item under it is one tool call Ace judged. For every item the archive
stores the decision, the replacement conclusion, a pointer back to the source, and the
model-visible content before and after.

RQ5 asks whether an evaluator can reconstruct what was removed, what replaced it, and
where the exact evidence remains. This script answers that by counting, not by sampling.

Usage:  python3 rq5_audit_completeness.py [--elpis-home PATH]

Reported reduction is over TOOL-CALL CONTENT THE PRUNER REVIEWED ONLY. It is not a
percentage of the whole context: the pruner never touches user messages, the system
prompt, or assistant text, so those are outside the denominator by construction.
"""

import argparse
import collections
import json
import pathlib
import re
import sys


def load_items(passes_dir):
    """Yield (pass_id, manifest, item_dict) for every archived decision."""
    for pass_dir in sorted(p for p in passes_dir.iterdir() if p.is_dir()):
        manifest = {}
        manifest_path = pass_dir / "manifest.json"
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text())
            except json.JSONDecodeError:
                pass
        items_dir = pass_dir / "items"
        if not items_dir.is_dir():
            continue
        for item_path in sorted(items_dir.glob("*.json")):
            try:
                yield pass_dir.name, manifest, json.loads(item_path.read_text())
            except json.JSONDecodeError:
                yield pass_dir.name, manifest, None


def preserved_call_ids(sessions_dir):
    """Every tool-call id still present in a session rollout on disk."""
    ids = set()
    for rollout in sessions_dir.rglob("*.jsonl"):
        try:
            ids.update(re.findall(r'"call_id"\s*:\s*"([^"]+)"', rollout.read_text(errors="ignore")))
        except OSError:
            continue
    return ids


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--elpis-home", type=pathlib.Path, default=pathlib.Path.home() / ".elpis")
    args = parser.parse_args()

    passes_dir = args.elpis_home / "logs/pruning/passes"
    sessions_dir = args.elpis_home / "sessions"
    if not passes_dir.is_dir():
        sys.exit(f"no pruning archive at {passes_dir}")

    triggers = collections.Counter()
    models = collections.Counter()
    passes = set()
    unreadable = 0
    kept = deleted = 0
    kept_before = kept_after = deleted_before = 0
    has_decision = has_pointer = has_original = kept_with_conclusion = 0
    pointers = []

    for pass_id, manifest, item in load_items(passes_dir):
        if pass_id not in passes:
            passes.add(pass_id)
            triggers[manifest.get("trigger")] += 1
            models[manifest.get("model")] += 1
        if item is None:
            unreadable += 1
            continue

        decision = item.get("decision")
        has_decision += decision in ("kept", "deleted")
        pointer = item.get("source_pointer") or ""
        has_pointer += bool(pointer)
        pointers.append(pointer.rsplit("/", 1)[-1])

        before = len(json.dumps(item.get("model_visible_before") or []))
        after = len(json.dumps(item.get("model_visible_after") or []))
        has_original += before > 2

        if decision == "kept":
            kept += 1
            kept_before += before
            kept_after += after
            kept_with_conclusion += bool(item.get("conclusion"))
        else:
            deleted += 1
            deleted_before += before

    items = kept + deleted
    reviewed = kept_before + deleted_before
    live = preserved_call_ids(sessions_dir)
    resolved = sum(1 for cid in pointers if cid in live)

    pct = lambda n, d: f"{n / d:.1%}" if d else "n/a"
    print(f"passes archived            {len(passes)}")
    print(f"  by trigger               {dict(triggers)}")
    print(f"  by Ace model             {dict(models)}")
    print(f"decisions recorded         {items:,}   (unreadable: {unreadable})")
    print()
    print("--- Reconstructability (RQ5) ---")
    print(f"  decision present         {has_decision:,}  {pct(has_decision, items)}")
    print(f"  source pointer present   {has_pointer:,}  {pct(has_pointer, items)}")
    print(f"  original text captured   {has_original:,}  {pct(has_original, items)}")
    print(f"  kept items w/ conclusion {kept_with_conclusion:,}/{kept:,}  {pct(kept_with_conclusion, kept)}")
    print(f"  pointer resolves to a live rollout  {resolved:,}/{len(pointers):,}  {pct(resolved, len(pointers))}")
    print(f"    dangling               {len(pointers) - resolved:,}  (original still held in the audit record)")
    print()
    print("--- Reduction over reviewed tool output ONLY ---")
    print(f"  kept     {kept:>5}  {kept_before:>12,} -> {kept_after:>10,}  {pct(kept_before - kept_after, kept_before)} compressed")
    print(f"  deleted  {deleted:>5}  {deleted_before:>12,} -> {0:>10}  100.0% removed")
    print(f"  total    {items:>5}  {reviewed:>12,} -> {kept_after:>10,}  {pct(reviewed - kept_after, reviewed)}")
    print()
    print("  NOT a share of total context. User messages, system prompt and assistant")
    print("  text are never eligible for pruning and are excluded from the denominator.")


if __name__ == "__main__":
    main()
