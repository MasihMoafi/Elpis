"""Regenerate both figures in the paper from context_retention.csv.

Usage:  python3 make_figures.py
Writes: ../figures/fig_context_retention.pdf
        ../figures/fig_persona_breakdown.pdf
"""

import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

for f in fm.findSystemFonts(fontpaths=["/usr/share/texmf/fonts/opentype/public/lm"]):
    fm.fontManager.addfont(f)
plt.rcParams["font.family"] = "Latin Modern Roman"
plt.rcParams["mathtext.fontset"] = "cm"
plt.rcParams["axes.unicode_minus"] = False

# reference palette (dataviz skill, light mode)
BLUE = "#2a78d6"        # categorical slot 1 -- Elpis (emphasis hue)
GRAY = "#898781"        # muted ink -- Codex (de-emphasis)
GRAY_TEXT = "#52514e"   # secondary ink
INK = "#0b0b0b"         # primary ink
GRID = "#e1e0d9"        # hairline gridline
AXIS = "#c3c2b7"        # baseline/axis
SURFACE = "#fcfcfb"

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, os.pardir, "figures")
MODELS = ["Luna", "Terra", "Sol"]
TURNS = [1, 2, 3]
TURN_LABELS = ["Turn 1\nfamiliarize", "Turn 2\nperformance\n(pressure-pruned)", "Turn 3\nUX"]

with open(os.path.join(HERE, "context_retention.csv")) as fh:
    DATA = {}
    for r in csv.DictReader(fh):
        DATA.setdefault(r["system"], {}).setdefault(r["model"], {})[int(r["turn"])] = (
            float(r["mean_remaining_pct"]),
            float(r["min_remaining_pct"]),
            float(r["max_remaining_pct"]),
        )


def series(system, model, idx):
    return [DATA[system][model.lower()][t][idx] for t in TURNS]


def pooled(system, idx, agg):
    return [agg(DATA[system][m.lower()][t][idx] for m in MODELS) for t in TURNS]


def mean_of(vals):
    vals = list(vals)
    return round(sum(vals) / len(vals), 1)


elpis_mean = pooled("elpis", 0, mean_of)
elpis_lo = pooled("elpis", 1, min)
elpis_hi = pooled("elpis", 2, max)
codex_mean = pooled("codex", 0, mean_of)
codex_lo = pooled("codex", 1, min)
codex_hi = pooled("codex", 2, max)

personas = {
    m: dict(
        elpis_mean=series("elpis", m, 0), elpis_lo=series("elpis", m, 1), elpis_hi=series("elpis", m, 2),
        codex_mean=series("codex", m, 0), codex_lo=series("codex", m, 1), codex_hi=series("codex", m, 2),
    )
    for m in MODELS
}


def style_axes(ax):
    ax.set_facecolor(SURFACE)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(AXIS)
    ax.spines["bottom"].set_color(AXIS)
    ax.tick_params(colors=GRAY_TEXT, labelsize=9)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)


# ---------- Figure A: main retention comparison ----------
fig, ax = plt.subplots(figsize=(6.0, 3.6), dpi=300)
style_axes(ax)

# The pruner fires when the window is 30% used, i.e. at 70% remaining. The default is a
# constant in context_pruner.rs and is reconfigurable at runtime with /force-prune.
ax.axhline(70, color=GRAY, linewidth=0.9, linestyle=(0, (4, 3)), zorder=1)
ax.text(1.85, 70, "70% default prune trigger", fontsize=8, color=GRAY_TEXT, va="center", ha="center",
        bbox=dict(facecolor=SURFACE, edgecolor="none", pad=2), zorder=5)
ax.axhline(93, color=AXIS, linewidth=0.8, linestyle=(0, (1, 2)), zorder=1)
ax.text(1.85, 93, "93% system-prompt ceiling", fontsize=8, color=GRAY_TEXT, va="center", ha="center",
        bbox=dict(facecolor=SURFACE, edgecolor="none", pad=2), zorder=5)

ax.fill_between(TURNS, codex_lo, codex_hi, color=GRAY, alpha=0.16, zorder=2, linewidth=0)
ax.plot(TURNS, codex_mean, color=GRAY, linewidth=1.6, marker="o", markersize=4.5, zorder=3,
        label="Codex (baseline)")

ax.fill_between(TURNS, elpis_lo, elpis_hi, color=BLUE, alpha=0.18, zorder=2, linewidth=0)
ax.plot(TURNS, elpis_mean, color=BLUE, linewidth=2.2, marker="o", markersize=5.5, zorder=4, label="Elpis")

# direct end labels
for t, dx in zip(TURNS, (-4, 0, 4)):
    ax.annotate(f"{elpis_mean[t - 1]:.1f}%", (t, elpis_mean[t - 1]), textcoords="offset points",
                xytext=(dx, 9), fontsize=8.5, color=BLUE, ha="center", fontweight="bold")
    ax.annotate(f"{codex_mean[t - 1]:.1f}%", (t, codex_mean[t - 1]), textcoords="offset points",
                xytext=(dx, -13), fontsize=8.5, color=GRAY_TEXT, ha="center")

ax.annotate("pressure prune\nfires here", xy=(2, elpis_mean[1]), xytext=(2.4, 60),
            fontsize=7.7, color=BLUE, ha="left", va="center",
            arrowprops=dict(arrowstyle="-", color=BLUE, linewidth=0.7, shrinkA=2, shrinkB=6))

ax.set_xlim(0.75, 3.85)
ax.set_ylim(0, 100)
ax.set_xticks(TURNS)
ax.set_xticklabels(TURN_LABELS, fontsize=8.3, color=INK)
ax.set_ylabel("Active context remaining (%)", fontsize=9.5, color=INK)

leg = ax.legend(loc="lower left", frameon=False, fontsize=9, handlelength=1.6, borderaxespad=0.3)
for text in leg.get_texts():
    text.set_color(INK)

fig.tight_layout()
fig.savefig(os.path.join(OUT, "fig_context_retention.pdf"))
plt.close(fig)

# ---------- Figure B: per-model small multiples ----------
fig, axes = plt.subplots(1, 3, figsize=(6.3, 2.5), dpi=300, sharey=True)
for ax, (name, d) in zip(axes, personas.items()):
    style_axes(ax)
    ax.fill_between(TURNS, d["codex_lo"], d["codex_hi"], color=GRAY, alpha=0.16, zorder=2, linewidth=0)
    ax.plot(TURNS, d["codex_mean"], color=GRAY, linewidth=1.3, marker="o", markersize=3.2, zorder=3)
    ax.fill_between(TURNS, d["elpis_lo"], d["elpis_hi"], color=BLUE, alpha=0.18, zorder=2, linewidth=0)
    ax.plot(TURNS, d["elpis_mean"], color=BLUE, linewidth=1.9, marker="o", markersize=3.8, zorder=4)
    ax.set_title(f"{name} (GPT-5.6)", fontsize=9.5, color=INK, pad=5)
    ax.set_xlim(0.8, 3.2)
    ax.set_ylim(0, 100)
    ax.set_xticks(TURNS)
    ax.set_xticklabels(["T1", "T2", "T3"], fontsize=8, color=GRAY_TEXT)

axes[0].set_ylabel("Context remaining (%)", fontsize=9, color=INK)

handles = [
    plt.Line2D([0], [0], color=BLUE, linewidth=2.2, marker="o", markersize=5, label="Elpis"),
    plt.Line2D([0], [0], color=GRAY, linewidth=1.6, marker="o", markersize=4, label="Codex (baseline)"),
]
fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, 1.04), ncol=2, frameon=False, fontsize=9)

fig.tight_layout(rect=[0, 0, 1, 0.95])
fig.savefig(os.path.join(OUT, "fig_persona_breakdown.pdf"))
plt.close(fig)

print("wrote fig_context_retention.pdf and fig_persona_breakdown.pdf")
