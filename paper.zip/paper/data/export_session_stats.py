#!/usr/bin/env python3
"""Export one row per preserved session, from the rollouts, for the RQ1 figures.

Each model request writes a `token_count` record into its session rollout, carrying the
tokens actually sent for that request and the model's context window. That makes the
context curve of every past session recoverable after the fact, from evidence on disk,
without re-running anything.

    active context = last_token_usage.input_tokens
    remaining %    = 100 * (1 - active / model_context_window)

`total_token_usage` is the wrong field here -- it accumulates over the session, so
dividing it by the window goes negative on any long run. It answers what the session
cost, not how full the context was.

Writes session_stats.csv:  system, session, model, requests, floor_pct, final_pct,
                           median_pct, prune_saved_tokens

Usage:  python3 export_session_stats.py
"""

import argparse
import csv
import json
import os
import pathlib
import statistics


def session_row(path):
    """One session's context curve, or None if it is too short to say anything."""
    remaining, saved, model = [], 0, ""
    for line in path.open(errors="ignore"):
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        payload = record.get("payload") if isinstance(record.get("payload"), dict) else record
        if payload.get("type") != "token_count":
            continue
        info = payload.get("info") or {}
        window = info.get("model_context_window")
        active = (info.get("last_token_usage") or {}).get("input_tokens")
        saved = max(saved, payload.get("context_prune_saved_tokens") or 0)
        model = payload.get("model") or info.get("model") or model
        if window and active:
            remaining.append(100.0 * (1 - active / window))
    return remaining, saved, model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-requests", type=int, default=5,
                        help="sessions shorter than this never exercise context at all")
    parser.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                      "session_stats.csv"))
    args = parser.parse_args()

    homes = {"elpis": pathlib.Path.home() / ".elpis", "codex": pathlib.Path.home() / ".codex"}
    rows = []
    for system, home in homes.items():
        sessions_dir = home / "sessions"
        if not sessions_dir.is_dir():
            continue
        for rollout in sorted(sessions_dir.rglob("*.jsonl")):
            remaining, saved, model = session_row(rollout)
            if len(remaining) < args.min_requests:
                continue
            rows.append({
                "system": system,
                "session": rollout.stem,
                "model": model,
                "requests": len(remaining),
                "floor_pct": round(min(remaining), 2),
                "final_pct": round(remaining[-1], 2),
                "median_pct": round(statistics.median(remaining), 2),
                "prune_saved_tokens": saved,
            })

    with open(args.out, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    pruned = sum(1 for r in rows if r["prune_saved_tokens"] > 0)
    print(f"wrote {args.out}")
    print(f"  {len(rows)} sessions   elpis={sum(1 for r in rows if r['system'] == 'elpis')}"
          f"  codex={sum(1 for r in rows if r['system'] == 'codex')}")
    print(f"  pruning ran in {pruned}")


if __name__ == "__main__":
    main()
