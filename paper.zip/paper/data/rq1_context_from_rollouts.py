#!/usr/bin/env python3
"""RQ1 - Context efficiency, rebuilt from preserved session records rather than by eye.

Every model request writes a `token_count` record into the session rollout. Each record
carries the tokens sent for THAT request and the model's context window, so the active
context at any point is recoverable after the fact, from evidence, without re-running.

    active context   = last_token_usage.input_tokens      <- what was actually sent
    remaining %      = 100 * (1 - active / model_context_window)

Do NOT use `total_token_usage` for this. That field accumulates across the whole session,
so dividing it by the window yields percentages that fall below zero on any long run. It
answers "what did this session cost", not "how full is the context".

Usage:
    python3 rq1_context_from_rollouts.py                 # summary per condition
    python3 rq1_context_from_rollouts.py --curves        # per-request curves
    python3 rq1_context_from_rollouts.py --home ~/.codex # the baseline arm

Caveat on the split below: sessions are grouped by whether pruning ever ran, which is NOT
a controlled comparison. Sessions where pruning never ran are mostly short ones that never
built enough pressure to trigger it. Treat the two groups as descriptive, not as arms of
an experiment -- a real comparison needs the same prompts run against both configurations.
"""

import argparse
import json
import pathlib
import statistics


def session_series(path):
    """(remaining_pct per request, peak prune savings) for one rollout file."""
    remaining, saved = [], 0
    for line in path.open(errors="ignore"):
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        payload = record.get("payload") if isinstance(record.get("payload"), dict) else record
        if payload.get("type") != "token_count":
            continue
        info = payload.get("info") or {}
        window = info.get("model_context_window")
        active = (info.get("last_token_usage") or {}).get("input_tokens")
        saved = max(saved, payload.get("context_prune_saved_tokens") or 0)
        if window and active:
            remaining.append(100.0 * (1 - active / window))
    return remaining, saved


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--home", type=pathlib.Path, default=pathlib.Path.home() / ".elpis")
    parser.add_argument("--curves", action="store_true", help="print each session's curve")
    parser.add_argument("--min-requests", type=int, default=5)
    args = parser.parse_args()

    sessions = []
    for rollout in sorted((args.home / "sessions").rglob("*.jsonl")):
        remaining, saved = session_series(rollout)
        if len(remaining) >= args.min_requests:
            sessions.append((rollout.name, remaining, saved))

    if not sessions:
        raise SystemExit(f"no usable sessions under {args.home}/sessions")

    pruned = [s for s in sessions if s[2] > 0]
    unpruned = [s for s in sessions if s[2] == 0]

    for label, group in (("pruning ran", pruned), ("pruning never ran", unpruned)):
        if not group:
            continue
        floors = sorted(min(r) for _, r in ((n, r) for n, r, _ in group))
        print(f"\n{label}: {len(group)} sessions")
        print(f"  floor (lowest % context remaining)")
        print(f"    median {statistics.median(floors):5.1f}%"
              f"    worst {floors[0]:5.1f}%    best {floors[-1]:5.1f}%")
        if len(floors) > 1:
            print(f"    stdev  {statistics.stdev(floors):5.1f}")

    if args.curves:
        print("\nper-request curves (first 10 requests)")
        for name, remaining, saved in sorted(sessions, key=lambda s: -s[2])[:10]:
            head = "  ".join(f"{v:5.1f}" for v in remaining[:10])
            print(f"  {name[:40]:42} saved={saved:>8,}  {head}")

    print("\nA floor that settles near the configured pressure threshold is the expected")
    print("signature of pruning holding the working set, rather than context growing")
    print("until the window runs out.")


if __name__ == "__main__":
    main()
