#!/usr/bin/env python3
"""Export per-turn context readings from preserved rollouts, without manual auditing.

A rollout records the user's messages and every model request in the order they happened,
so turn boundaries are recoverable after the fact: turn 1 runs from the first user message
to the second, and so on. Every model request inside a turn carries its own reading of how
full the context was when it was sent.

    active context = last_token_usage.input_tokens
    remaining %    = 100 * (1 - active / model_context_window)

`total_token_usage` is the wrong field: it accumulates over the session, so dividing it by
the window goes negative on long runs. It says what the session cost, not how full it got.

Writes turn_curves.csv: system, session, turn, request, seq, remaining_pct, pruned

`request` counts within the turn; `seq` counts across the whole session, which is what a
trajectory needs -- context accumulates over the session, not over the turn.

`pruned` marks sessions where the pruner ever ran, which is the only automatic signal
separating the two conditions in the archive.

Usage:  python3 export_turn_curves.py
"""

import csv
import json
import os
import pathlib


def is_real_user_turn(payload):
    """A user message that starts a turn, not session preamble.

    Every session opens with injected context -- environment, instructions, the user's
    config -- recorded the same way as typed input. Counting those as turns would put
    three or four "turns" before the first request of the session.
    """
    if payload.get("type") != "user_message":
        return False
    kind = payload.get("kind")
    return kind in (None, "plain")


def session_turns(path):
    """[(turn_index, request_in_turn, request_in_session, remaining_pct)] for one rollout."""
    rows, turn, request, seq, pruned = [], 0, 0, 0, False
    for line in path.open(errors="ignore"):
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        payload = record.get("payload") if isinstance(record.get("payload"), dict) else record
        if is_real_user_turn(payload):
            turn += 1
            request = 0
            continue
        if payload.get("type") != "token_count":
            continue
        if payload.get("context_prune_saved_tokens"):
            pruned = True
        info = payload.get("info") or {}
        window = info.get("model_context_window")
        active = (info.get("last_token_usage") or {}).get("input_tokens")
        if not (window and active) or turn == 0:
            continue
        request += 1
        seq += 1
        rows.append((turn, request, seq, round(100.0 * (1 - active / window), 2)))
    return rows, pruned


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    homes = {"elpis": pathlib.Path.home() / ".elpis", "codex": pathlib.Path.home() / ".codex"}

    out_rows = []
    for system, home in homes.items():
        sessions_dir = home / "sessions"
        if not sessions_dir.is_dir():
            continue
        for rollout in sorted(sessions_dir.rglob("*.jsonl")):
            rows, pruned = session_turns(rollout)
            if len(rows) < 5:
                continue
            for turn, request, seq, pct in rows:
                out_rows.append({
                    "system": system,
                    "session": rollout.stem,
                    "turn": turn,
                    "request": request,
                    "seq": seq,
                    "remaining_pct": pct,
                    "pruned": int(pruned),
                })

    out = os.path.join(here, "turn_curves.csv")
    with open(out, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(out_rows[0].keys()))
        writer.writeheader()
        writer.writerows(out_rows)

    sessions = {(r["system"], r["session"]) for r in out_rows}
    pruned = {(r["system"], r["session"]) for r in out_rows if r["pruned"]}
    print(f"wrote {out}")
    print(f"  {len(out_rows):,} readings across {len(sessions)} sessions")
    print(f"  pruner ran in {len(pruned)}")


if __name__ == "__main__":
    main()
