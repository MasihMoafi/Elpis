**Elpis**

**Auditable Context Management and Pressure-Triggered Pruning for Coding
Agents**

**Masih Moafi**  
Independent Researcher  
August 2026

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Project thesis</strong></p>
<p>You run an agent inside Elpis, and it becomes Elpis. The model may
change; the surrounding context policy, continuity, evidence, and user
control remain coherent.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

**Abstract**

| Coding agents accumulate file reads, searches, command output, failed approaches, and test logs in the same active context used for later reasoning. Most of this evidence is valuable when produced but expensive after its conclusion is known. Elpis is a provider-neutral coding-agent environment that treats context as a controlled working set rather than an ever-growing transcript. Its four-layer pipeline combines RTK shell-output filtering, a deterministic large-output cap inherited from Codex, and two author-designed Ace passes: steady selective pruning and pressure-triggered pruning. Ace runs as a separate model pass at checkpoints between model follow-ups and at turn completion. It reviews only eligible tool evidence from completed turns. Useful evidence becomes a compact conclusion plus an exact pointer to the durable record; dead ends leave the working context. Every applied pass writes an immutable audit containing its input, raw response, decisions, and exact before-and-after representations before model-visible history is changed. Elpis also provides a Context Ledger for explicit source admission, a /context view for category-level accounting, and deterministic provider-neutral continuity through GOAL.md and ES.md. This paper presents the design, implementation contract, and a reproducible evaluation plan. Historical context-retention figures are retained only as motivating observations because their original per-run records were not preserved. |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

*Keywords: coding agents, context management, context pruning,
auditability, observability, session continuity*

# 1. Introduction

A coding agent does not merely write code. It searches a repository,
reads files, runs commands, observes failures, edits several paths, and
verifies the result. Each action produces text that may be carried into
the next model request. Over a long session, the active context
gradually stops being a compact description of the work and becomes a
detailed story of how the agent reached its current state.

The author’s motivating observation was practical: **tool calls often
consume more of the active context than the user’s request, goal, or
final decisions**. A small prompt can trigger repeated searches, broad
file reads, terminal output, diagnostics, and retries. These events are
necessary during exploration, but their verbatim form rarely remains
equally useful after the agent has extracted a conclusion. Figure 1
shows the accumulation pattern. The final submission should replace this
conceptual rendering with the repository screenshot at
docs/assets/showcase-of-how-much-tool-calls.png.

<img src="media/media/image1.png"
style="width:6.37795in;height:3.2315in" />

*Figure 1. Conceptual rendering of the tool-call accumulation pattern
that motivated Elpis. The repository contains the real Antigravity
screenshot intended for the final paper.*

This produces three linked problems. First, later requests repeatedly
pay for old exploration. Second, task state - the active goal,
constraints, changed files, verification, and blockers - competes with
transient logs. Third, conventional truncation or full-history
compaction can make removal difficult to inspect. A summary may be
concise while leaving the user unable to answer: *What disappeared? What
replaced it? Where is the exact evidence?*

Elpis addresses the problem at the environment layer rather than by
changing the foundation model. It separates two objects that
conventional transcripts conflate: a small working context for the next
inference, and a durable record for evidence, recovery, and later
inspection. The selected agent continues to run the model loop; Elpis
manages what surrounds that loop - context admission, pruning,
continuity, evidence, permissions, and provider choice.

The project name and identity are intentionally personal. In Elpis
terminology, an agent operating inside the environment is *an Elpis*.
The idea is inspired by Bruce Lee’s image of water taking the shape of
its container: a model enters the environment and adopts its context
policy, continuity, rules, evidence, and controls. This identity is not
a technical claim, but it explains the product thesis: **different
models can inherit the same coherent working environment.**

Commercial incentives do not always align with minimizing repeated
inference and token consumption. Elpis therefore places context
accounting and context mutation under local, user-visible control rather
than assuming that a provider will optimize them for the user. This is
motivation, not evidence of deliberate behavior by any laboratory.

## 1.1 Contributions

The contributions are intentionally unequal in weight:

1.  Ace steady selective pruning. A separate model pass reviews eligible
    tool evidence from completed turns once a small configurable backlog
    accumulates. Useful evidence becomes a compact conclusion plus an
    exact pointer; dead ends leave the working context.

2.  Ace pressure-triggered pruning. The same selective judgment is
    activated when context use crosses a configured pressure boundary,
    covering sudden tool-heavy growth that routine steady pruning cannot
    contain in time.

3.  Audit-before-mutation. Every applied Ace pass records its input, raw
    response, keep/delete decisions, and exact model-visible
    before-and-after items before changing working history.

4.  Observable context control. The Context Ledger controls admitted
    portable sources, while /context explains which categories consumed
    the model window.

5.  Deterministic portable continuity. GOAL.md and the author-designed
    ES.md preserve current task state across provider changes and fresh
    threads without replaying the entire transcript.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Quality and quantity</strong></p>
<p>Quality means a higher signal-to-noise working set: dead ends
disappear, while useful conclusions retain exact evidence pointers.
Quantity means more meaningful turns fit before fallback/native
compaction is required.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

# 2. Context as a Working Set

## 2.1 Different information has different lifetimes

A coding session contains information with different useful lifetimes:

- Durable: project rules, explicit constraints, the active objective,
  and carefully curated long-term facts.

- Task-level: decisions, changed paths, blockers, verification results,
  and the latest checkpoint.

- Turn-level: searches, directory listings, file reads, command probes,
  temporary diffs, test logs, and dead ends.

A raw transcript treats these categories alike. Elpis keeps the exact
transcript and tool evidence on disk while controlling which forms
remain in the next request. The objective is not to erase history. It is
to separate the active working set from the durable record.

## 2.2 Why truncation and compaction are insufficient

Deterministic truncation protects a hard context limit, but it cannot
determine which evidence will matter later. Full compaction can preserve
meaning, but it replaces many inspectable events with a single account.
Retrieval can recover external information, but it does not by itself
define when completed-turn evidence should leave the active prompt or
how that mutation should be audited. Elpis combines these mechanisms
rather than treating any one of them as a complete context policy.

## 2.3 Design requirements

- Elpis must expose what enters the model request, its size, its source,
  and why it remains.

- Completed-turn exploration may leave only after a conclusion and an
  exact evidence pointer are retained when needed.

- Current-turn evidence remains verbatim; the system does not prune
  observations while the active reasoning step still depends on them.

- Failure of the pruning model or audit write must leave working history
  unchanged.

- Goals, decisions, changed files, commands, verification, blockers, and
  next action must survive restarts.

- Exact native resume and provider-neutral lean continuation remain
  explicit, separate choices.

# 3. System Design

<img src="media/media/image2.png"
style="width:5.66929in;height:3.16813in" />

*Figure 2. Elpis context lifecycle. Layers 1 and 2 reduce or bound
output before model consumption; Layers 3 and 4 selectively transform
eligible evidence from completed turns. Exact evidence remains durable.*

## 3.1 Four layers of context control

| **Layer**        | **Origin** | **Trigger**                                                          | **Scope**                                    | **Behavior**                                                                    |
|------------------|------------|----------------------------------------------------------------------|----------------------------------------------|---------------------------------------------------------------------------------|
| 1\. RTK filter   | RTK        | Before supported shell output reaches the model                      | Supported command output                     | Rewrites verbose command output into a more compact form.                       |
| 2\. Safety cap   | Codex      | Exceptionally large tool result                                      | All tool output                              | Applies a deterministic upper bound and visible truncation notice.              |
| 3\. Ace steady   | Elpis      | Small configurable backlog of uncovered completed-turn tool evidence | Whole eligible backlog                       | Keeps useful conclusions plus exact pointers; removes dead ends.                |
| 4\. Ace pressure | Elpis      | Configured context-pressure boundary                                 | Enough old eligible evidence to reach target | Reclaims toward a safer working-set target; native compaction remains fallback. |

The first two layers are credited rather than claimed as novel. RTK is
installed as a separate tool and provides pre-model shell-output
filtering. The deterministic safety cap is inherited from the pinned
Codex foundation unchanged. The primary contributions are the two Ace
modes.

## 3.2 Ace is a separate model pass

Ace is not the same call that answers the user. It is a distinct
context-control pass, currently configured with GPT-5.6 Luna at maximum
reasoning. Trigger checks occur both between model follow-ups and at the
end of a turn. This matters because a single long, tool-heavy turn may
contain many model-tool-model cycles before the user sees a final
response; it must not evade context control merely by remaining inside
one nominal turn.

The steady and pressure modes use the same keep-or-remove judgment but
have different purposes. Steady pruning prevents routine accumulation.
Pressure-triggered pruning covers a large turn or residual backlog that
reaches the pressure boundary before the steady path can recover enough
space. The exact steady threshold is a configurable policy parameter,
not the research contribution.

## 3.3 Eligibility and replacement

Ace receives only tool evidence from earlier completed turns. User
messages, assistant messages, and current-turn evidence are not
rewritten. Each eligible item is classified as:

- Useful: replace the verbatim item in working history with a compact
  conclusion and an exact evidence pointer.

- Disposable: remove the item from working history because it represents
  a dead end or redundant exploration.

The original item remains in the provider transcript or durable rollout
record. Elpis therefore asks two separate questions: what does the next
model request need, and what may a reviewer need to inspect later?

## 3.4 Reference procedure

> CHECKPOINT()  
> measure exact model-window use  
> if pressure boundary crossed:  
> mode \<- pressure  
> scope \<- oldest eligible evidence needed to approach target  
> else if uncovered completed-turn evidence crosses steady threshold:  
> mode \<- steady  
> scope \<- entire eligible backlog  
> else:  
> return  
>   
> response \<- ACE_MODEL(scope, policy)  
> validate response and decisions  
> write immutable audit(input, response, decisions, before, after)  
> if audit write fails:  
> return without mutation  
> atomically apply replacements/removals  
> recompute working-context use  
> if pressure remains and nothing reclaimable exists:  
> request native compaction fallback

# 4. Auditability and Observability

## 4.1 Audit before mutation

Every successfully applied pass writes an immutable audit before the
working history changes. The audit contains the exact Ace instructions
and input, the separate model’s raw response, every reviewed tool-call
identifier, the keep/delete decision, and each item’s exact
model-visible before and after form. If the audit cannot be written, the
previous working history remains in place and the pass is not recorded
as applied.

~/.elpis/logs/  
├── prune_report.md  
└── pruning/passes/\<pass-id\>/  
├── ace.json  
├── manifest.json  
└── items/\*.json

This order turns auditability into a state-transition rule rather than a
documentation promise. The system cannot enter a pruned state without
first preserving an explanation of that state.

## 4.2 Context Ledger

The Context Ledger is a TUI panel that lists portable sources admitted
to the next request, including their sizes and inclusion state. A toggle
is behavioral: it writes the source’s admission state and changes the
next assembled request. Sources include GOAL.md, ES.md, applicable
rules, explicitly selected files, and memory only when memory is
enabled.

## 4.3 /context accounting

The ledger answers *what Elpis intentionally admits*. The /context view
answers *what filled the current model window*. It separates user
messages, agent responses, tool calls, system instructions, skills, and
free space, and shows available backtrack checkpoints. Keeping the views
separate prevents a misleading conclusion: a small set of admitted files
does not imply a small active context if conversation or tool output
dominates the request.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Single accounting contract</strong></p>
<p>Displayed percentages are computed against the selected model’s
context window and explicitly distinguish used from remaining context.
After pruning or compaction, Elpis recomputes the working-history
estimate.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

# 5. Provider-Neutral Session Continuity

Context control is incomplete if a fresh thread loses the goal and
verified work state. Elpis therefore separates provider-native
conversation state from portable task state.

## 5.1 Exact resume and lean continuation

| **Mode**          | **State source**                               | **Trade-off**                                                                                           |
|-------------------|------------------------------------------------|---------------------------------------------------------------------------------------------------------|
| Exact resume      | Provider thread and accumulated native history | Highest conversational continuity, but provider-bound and still growing.                                |
| Lean continuation | GOAL.md, ES.md, and admitted rules             | Small, editable, provider-neutral checkpoint; intentionally not identical to the original conversation. |

## 5.2 ES.md

ES.md is an author-designed continuity artifact built specifically for
Elpis. It is not a free-form model summary. It is deterministically
generated from completed-turn events and records the latest result,
changed files, executed commands, status, and the location of exact
evidence. Its plain-Markdown form is provider-neutral and independent of
any provider’s native thread representation.

\# Elpis Session Checkpoint  
  
- Workspace: /path/to/project  
- Thread: \<thread_id\>  
- Turn: \<turn_id\>  
- Status: \<status\>  
  
\## Latest Result  
\<final result\>  
  
\## Changed Files  
- path/to/file.rs (modified)  
  
\## Commands  
- cargo test (exit 0)  
  
\## Exact Evidence  
- Full turn remains in the provider transcript.

GOAL.md and ES.md are written through temporary paths and renamed into
place so interruption cannot leave a partially written checkpoint. If
ES.md cannot be saved, the turn completes but the failure is surfaced in
the transcript; continuity degrades visibly rather than silently.

## 5.3 Scope of memory and retrieval

Durable memory and optional retrieval are deliberately secondary in this
paper. Elpis exposes memory controls and can use an external RAG
service, but the central contribution is the lifecycle of active context
and session evidence. Memory is therefore treated as supporting
infrastructure rather than an originality claim.

# 6. Implementation

Elpis is implemented in Rust on a pinned Codex execution and TUI
foundation. The inherited foundation supplies terminal interaction,
model-loop integration, commands, patches, approvals, sandboxing,
sessions, and event rendering. Elpis adds the context, pruning,
continuity, admission, accounting, and evidence layers described here.

| **Concern**                     | **Main repository location**                                                    |
|---------------------------------|---------------------------------------------------------------------------------|
| Context pruning and application | codex-rs/core/src/context_pruner.rs; codex-rs/core/src/session/context_prune.rs |
| Pruning audit                   | codex-rs/core/src/session/context_prune_audit.rs                                |
| Portable context assembly       | codex-rs/core/src/elpis_context.rs                                              |
| Context Ledger UI               | codex-rs/tui/src/chatwidget/context_ledger.rs                                   |
| Checkpoint writing              | codex-rs/tui/src/elpis_context.rs                                               |
| Continuity contribution         | codex-rs/app-server/src/extensions.rs                                           |

The paper’s reproducibility record should pin the Elpis commit, upstream
Codex revision, operating-system image, model provider and identifiers,
reasoning settings, context windows, RTK version, hook configuration,
and evaluation prompts.

# 7. Evaluation and Current Evidence

A context manager is not better merely because it removes more tokens.
It must preserve goals, negative constraints, changed paths, and
verification state while reducing repeated prompt cost. The evaluation
must therefore pair efficiency with correctness.

## 7.1 Research questions

- RQ1 - Context efficiency: Does Elpis reduce active-context growth
  relative to the matched runtime without Elpis-specific pruning?

- RQ2 - Retention: After pruning, compaction, and restart, does the
  agent retain planted goals, negative constraints, changed paths, and
  verification state?

- RQ3 - Task correctness: Does the smaller working set preserve
  completion and clean test outcomes on multi-turn engineering tasks?

- RQ4 - Overhead: What model calls, wall-clock latency, and monetary
  cost does Ace add, and what prompt-token savings follow?

- RQ5 - Auditability: Can an evaluator reconstruct what was removed,
  what replaced it, and where the exact evidence remains?

## 7.2 Systems and ablations

The main comparison should use the same provider, model, reasoning
setting, system instructions, tool permissions, workspace image, and
prompt sequence. The cleanest baseline is the same pinned Codex
foundation with Elpis-specific context control disabled. Required
ablations are:

- Full four-layer pipeline.

- No RTK filtering.

- No steady Ace pass.

- No pressure Ace pass.

- Native compaction only.

- No lean checkpoint on restart.

## 7.3 Workloads and metrics

Two workload families isolate different failure modes. Controlled
continuity tasks plant exact facts, paraphrasable facts, and absent
facts, then force real pruning, compaction, and restart paths.
Repository engineering tasks require exploration, edits, and
verification under explicit constraints such as files that must not
change and APIs that must remain stable.

Record per turn: active tokens and percentage, tokens by category,
trigger type, raw and retained evidence size, exact and semantic recall,
false-positive rate on absent facts, constraint violations, task
success, test status, prompt and completion tokens, Ace-model tokens and
cost, wall-clock latency, and audit completeness. Report variation and
failures rather than one selected run.

## 7.4 What is supported today

| **Evidence class**       | **Supported**                                                                                             | **Not yet established**                                                         |
|--------------------------|-----------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------|
| Implementation contracts | Four layers, trigger paths, Context Ledger behavior, ES generation, atomic writes, audit-before-mutation. | Generalization across providers and workloads.                                  |
| Component checks         | Targeted tests and negative controls for admission and related contracts.                                 | Superior long-session coding success.                                           |
| Historical observations  | Repository charts and screenshots show the intended and previously observed context trajectory.           | Reproducible comparative statistics without preserved raw per-run records.      |
| Evaluation protocol      | Pinned protocol and deterministic scoring design exist.                                                   | A final Elpis-versus-Codex score until all raw runs and failures are published. |

This distinction is narrower and stronger than repeatedly apologizing
for missing results: the system behavior is implemented and inspectable;
the comparative performance claim remains gated on a preserved
evaluation record.

<img src="media/media/image3.png"
style="width:6.1811in;height:3.95005in" />

*Figure 3. Historical project-page context-retention view, reproduced
from the supplied draft. It is an illustrative observation, not a
controlled result, because the original raw runs were not preserved.*

# 8. Related Work

## 8.1 Pre-model output reduction

RTK rewrites or proxies common developer commands so that agents receive
compact shell output before it enters the model context \[2\]. Headroom
similarly compresses tool outputs, logs, files, RAG chunks, and other
inputs before forwarding them to an LLM \[4\]. These systems reduce
incoming material. Elpis incorporates RTK as its first layer but focuses
primarily on a later lifecycle question: what should happen to already
consumed tool evidence after a completed turn has yielded a conclusion?

## 8.2 Runtime truncation and compaction

Codex provides the execution foundation, deterministic output bounds,
and native compaction path used as Elpis’s fallback \[3\]. Truncation
protects the hard limit; compaction summarizes the broader conversation.
Elpis keeps these mechanisms but inserts selective completed-evidence
pruning before full compaction, with a separate audit contract and
user-visible accounting.

## 8.3 Memory and virtual context

MemGPT frames limited context as a virtual-memory problem and moves
information across memory tiers \[5\]. Elpis shares the separation
between a working set and external state, but its central object is the
evidence lifecycle of an interactive coding session: explicit source
admission, completed-turn pruning, exact evidence pointers, and
event-derived portable checkpoints. Durable memory is outside the main
claim.

## 8.4 Agent-computer interfaces

ReAct established the general pattern of interleaving reasoning and
environment actions \[7\]. SWE-agent showed that the interface exposed
to a coding model materially affects software-engineering performance
\[6\]. Elpis targets a different interface layer: not the action syntax
itself, but the visibility, retention, and mutation of information
produced across actions, turns, and sessions.

## 8.5 Positioning

Elpis is not simply a shell compressor, token proxy, retriever, memory
store, or summary command. Its contribution is the combination of: (1)
pre-model reduction; (2) selective completed-turn evidence replacement
under steady and pressure triggers; (3) immutable audit-before-mutation;
(4) explicit context admission and category-level accounting; and (5)
deterministic provider-neutral continuity. The paper should avoid
claiming that every component is novel; the novelty lies primarily in
Layers 3 and 4 and in the inspectable system built around them.

# 9. Limitations

First, Ace uses model-assisted judgment. A valid pass may still produce
an incomplete conclusion, even though current-turn evidence is protected
and failed passes make no change. Retention probes and engineering
constraints must measure this directly.

Second, exact evidence pointers preserve inspectability but do not
guarantee that the agent will retrieve old evidence when it becomes
relevant again. Elpis keeps the evidence available; retrieval policy
remains a separate problem.

Third, lean continuation depends on GOAL.md, ES.md, and admitted rules.
It is intentionally portable rather than identical to a provider-native
conversation.

Fourth, Ace adds a separate model call. Its cost and latency must be
justified against prompt-token savings and avoided compactions.

Fifth, the historical context-retention figures lack preserved raw run
records. They motivate the evaluation but cannot support a final
comparative claim.

Finally, the current evidence is centered on the available Linux/macOS
implementation and pinned provider routes. Cross-provider and
cross-platform behavior should be reported separately.

# 10. Conclusion

Elpis treats a coding session as two related but different objects: a
small working context for the next inference and a durable record for
evidence and recovery. Its main contribution is not a larger memory
store. It is an inspectable lifecycle for context.

The four-layer pipeline credits RTK and Codex for pre-model filtering
and deterministic bounding, then adds two author-designed Ace modes.
Steady pruning prevents routine accumulation; pressure-triggered pruning
covers sudden growth. Both preserve the current turn, retain useful
conclusions with exact evidence pointers, and remove dead ends from the
working set. An immutable audit is written before any mutation is
applied.

The Context Ledger, /context accounting, GOAL.md, and deterministic
ES.md extend the same principle from pruning to user control and
continuity. Together, these mechanisms aim to deliver more quality - a
clearer working set - and more quantity - more useful turns before
fallback compaction. The remaining publication task is a pinned repeated
comparison that preserves every transcript, result, failure, audit, and
scorer output.

<table>
<colgroup>
<col style="width: 100%" />
</colgroup>
<thead>
<tr class="header">
<th><p><strong>Elpis in one sentence</strong></p>
<p>The model performs the work; Elpis controls what the model carries
forward, what leaves the working set, and how every change remains
inspectable.</p></th>
</tr>
</thead>
<tbody>
</tbody>
</table>

# References

\[1\] Masih Moafi. Elpis: repository, technical guide, context
specification, session specification, and evaluation protocols. Public
repository; paper revision grounded in commit
760d7a2f41308d7cd45a24e74b204290d58d8af9.

\[2\] RTK contributors. RTK: a CLI proxy and hook system for reducing
token consumption from common developer commands. GitHub repository,
2026.

\[3\] OpenAI. Codex CLI. Apache-2.0 open-source coding-agent runtime and
terminal interface. GitHub repository, pinned upstream revision recorded
by Elpis.

\[4\] Headroom Labs. Headroom: compression for tool outputs, logs,
files, RAG chunks, and agent inputs. GitHub repository, 2026.

\[5\] Charles Packer, Sarah Wooders, Kevin Lin, Vivian Fang, Shishir G.
Patil, Ion Stoica, and Joseph E. Gonzalez. MemGPT: Towards LLMs as
Operating Systems. arXiv:2310.08560, 2023.

\[6\] John Yang, Carlos E. Jimenez, Alexander Wettig, Kilian Lieret,
Shunyu Yao, Karthik Narasimhan, and Ofir Press. SWE-agent:
Agent-Computer Interfaces Enable Automated Software Engineering. NeurIPS
2024; arXiv:2405.15793.

\[7\] Shunyu Yao, Jeffrey Zhao, Dian Yu, Nan Du, Izhak Shafran, Karthik
Narasimhan, and Yuan Cao. ReAct: Synergizing Reasoning and Acting in
Language Models. arXiv:2210.03629, 2022.

\[8\] Masih Moafi. rag-mcp: optional local semantic retrieval for
user-owned documents and workspaces. GitHub repository, 2026.

# Appendix A. Reproducibility Checklist

- Pin the Elpis commit and the matched upstream Codex revision.

- Record the provider, exact turn-model ID, Ace-model ID, reasoning
  settings, and context windows.

- Record the RTK version and hook configuration.

- Record the operating-system image, hardware, permissions, and sandbox
  policy.

- Use clean workspaces and identical prompt sequences.

- Preserve every transcript, result file, failure, audit, and scorer
  output.

- Publish generation code and source data for every quantitative figure.

- Report task correctness, cost, and latency separately.

- Keep historical charts explicitly labeled until their source records
  are recovered or the experiment is rerun.

# Appendix B. Claims Map

| **Claim**                                       | **Status**                  | **Required evidence**                                               |
|-------------------------------------------------|-----------------------------|---------------------------------------------------------------------|
| Four-layer context-control pipeline exists      | Implemented/documented      | Pinned source map and component tests.                              |
| Context Ledger changes next-turn admission      | Implemented/documented      | Positive and negative admission checks.                             |
| Ace writes audit before mutation                | Implemented contract        | Real pass export plus failure-path test.                            |
| ES.md is event-derived and provider-neutral     | Implemented/documented      | Checkpoint fixture and restart test.                                |
| Elpis preserves more context than baseline      | Historical observation only | Repeated matched runs with raw records.                             |
| Elpis improves task success or cost per success | Not yet established         | Repeated engineering benchmark with correctness, cost, and latency. |
