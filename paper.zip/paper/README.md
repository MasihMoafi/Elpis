# Elpis paper

TMLR submission. Double-blind — the built PDF must contain no name, email, or
local path.

## Source

- `main.tex` — the paper. This is the only file to edit.
- `references.bib` — bibliography. Self-citations use `author = {Anonymous}`;
  restore the real name only for the accepted/preprint build.
- `figures/fig_context_retention.pdf`, `figures/fig_persona_breakdown.pdf` — the
  two figures in use. Everything else in `figures/` is from earlier drafts.
- `tmlr.sty`, `tmlr.bst`, `fancyhdr.sty`, `math_commands.tex` — official TMLR
  style files, copied verbatim. Do not edit.

`paper.md` and the `.docx`/`.pdf` files are the earlier draft, kept for reference
only.

## Build

```bash
xelatex main.tex && bibtex main && xelatex main.tex && xelatex main.tex
```

`latexmk` is not installed here. Three xelatex passes are needed for the
cross-references and citations to settle.

## Anonymity check

After building, confirm the PDF is clean:

```bash
pdftotext main.pdf - | grep -inE "masih|moafi|gmail|/home/"
```

Empty output means it is safe to submit.

## De-anonymizing after acceptance

In `main.tex`, swap `\usepackage{tmlr}` for `\usepackage[accepted]{tmlr}` (or
`[preprint]`), and restore the real author name in `references.bib`.
